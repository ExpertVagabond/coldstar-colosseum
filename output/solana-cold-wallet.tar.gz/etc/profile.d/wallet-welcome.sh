#!/bin/sh
# Wallet boot message

clear
echo ""
echo "=============================================="
echo "     SOLANA COLD WALLET - OFFLINE MODE"
echo "=============================================="
echo ""

if [ -f /wallet/pubkey.txt ]; then
    echo "Wallet Public Key:"
    echo "--------------------------------------------"
    cat /wallet/pubkey.txt
    echo ""
    echo "--------------------------------------------"
else
    echo "Wallet not yet initialized."
    echo "Run: python3 /usr/local/bin/init_wallet.py"
    echo "to generate your wallet on this air-gapped device."
fi

echo ""
echo "SECURITY: This device has NO network access."
echo ""
echo "Commands:"
echo "  sign_tx.sh    - Sign a transaction"
echo ""
echo "Directories:"
echo "  /wallet       - Wallet keypair storage"
echo "  /inbox        - Place unsigned transactions here"
echo "  /outbox       - Signed transactions appear here"
echo ""
echo "=============================================="
echo ""
